=== Gold Price Display ===
Contributors: yourname
Tags: gold, price, thai, shortcode
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

Display Thai gold prices with simple shortcodes.

== Description ==

แสดงราคาทองไทยบนเว็บไซต์ WordPress ของคุณด้วย shortcode ง่ายๆ

== Installation ==

1. อัปโหลดโฟลเดอร์ `gold-price-display` ไปที่ `/wp-content/plugins/`
2. เปิดใช้งาน plugin ผ่าน Plugins menu
3. ตั้งค่า API URL ใน wp-config.php:
   `define('GOLD_PRICE_API_URL', 'https://your-api-url.com/api/gold/current');`
4. ใช้ shortcode ในหน้าหรือโพสต์

== Shortcodes ==

= แสดงราคาทองแบบเต็ม =
`[gold_price]`

= แสดงเฉพาะทองแท่ง =
`[gold_price type="bar"]`

= แสดงเฉพาะทองรูปพรรณ =
`[gold_price type="ornament"]`

= แสดงเฉพาะการเปลี่ยนแปลง =
`[gold_price type="change"]`

== Customization ==

แก้ไขไฟล์ `style.css` เพื่อปรับแต่ง:
- สี: แก้ไข CSS Variables ใน :root
- ขนาด: แก้ไข --gpd-font-size
- รัศมีมุม: แก้ไข --gpd-radius

== Changelog ==

= 1.0.0 =
* Initial release
