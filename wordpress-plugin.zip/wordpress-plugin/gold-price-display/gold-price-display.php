<?php
/**
 * Plugin Name: TH Gold Price
 * Plugin URI: https://line.me/ti/p/pond_che
 * Description: Display Thai gold prices from Gold Price
 * Version: 1.0.3
 * Author: Pond Dev.
 * Author URI: https://line.me/ti/p/pond_che
 * License: GPL v2 or later
 * Text Domain: th-gold-price
 */


if (!defined('ABSPATH')) {
    exit;
}
$GOLD_API_BASE_URL = 'https://gold-beer-production.up.railway.app';

class Gold_Price_Display {
    private static $instance = null;
    private $api_base_url;
    private $cache_time = 50;  // 2 minutes to sync with API refresh interval
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        global $GOLD_API_BASE_URL;
        $this->api_base_url = rtrim($GOLD_API_BASE_URL, '/');
        
        add_action('wp_enqueue_scripts', [$this, 'enqueue_styles']);
        add_shortcode('gold_price', [$this, 'shortcode_gold_price']);
        add_shortcode('calculator', [$this, 'shortcode_calculator']);
        
        // Admin settings
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('wp_ajax_gpd_clear_cache', [$this, 'ajax_clear_cache']);
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'TH Gold Settings',
            'TH Gold',
            'manage_options',
            'th-gold-settings',
            [$this, 'render_settings_page'],
            'dashicons-money-alt',
            100
        );
        
        add_submenu_page(
            'th-gold-settings',
            'TH Gold Settings',
            'TH Gold',
            'manage_options',
            'th-gold-settings',
            [$this, 'render_settings_page']
        );
    }
    
    /**
     * Enqueue admin scripts for color picker
     */
    public function enqueue_admin_scripts($hook) {
        if ($hook !== 'toplevel_page_th-gold-settings') {
            return;
        }
        
        wp_enqueue_style('wp-color-picker');
        wp_enqueue_script('wp-color-picker');
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('gpd_settings_group', 'gpd_theme_mode', [
            'type' => 'string',
            'default' => 'dark',
            'sanitize_callback' => [$this, 'sanitize_theme_mode']
        ]);
        
        register_setting('gpd_settings_group', 'gpd_gold_effect', [
            'type' => 'boolean',
            'default' => true,
            'sanitize_callback' => 'rest_sanitize_boolean'
        ]);
        
        // Color settings
        $color_settings = [
            'gpd_color_primary',    // Gold/accent color (card titles)
            'gpd_color_header',     // Header title color
            'gpd_color_online',     // Online status color
            'gpd_color_update',     // Update time color
            'gpd_color_bg',         // Background color
            'gpd_color_text',       // Text color
            'gpd_color_buy',        // Buy/green color
            'gpd_color_sell_value', // Sell value color (gpd-sell class)
            'gpd_color_down',       // Down badge/red color
            'gpd_color_border'      // Border color
        ];
        
        foreach ($color_settings as $setting) {
            register_setting('gpd_settings_group', $setting, [
                'type' => 'string',
                'default' => '',
                'sanitize_callback' => 'sanitize_hex_color'
            ]);
        }
    }
    
    /**
     * Sanitize theme mode
     */
    public function sanitize_theme_mode($value) {
        $allowed = ['dark', 'light', 'custom', 'none'];
        return in_array($value, $allowed) ? $value : 'dark';
    }
    
    /**
     * Inject custom CSS variables (called from enqueue_styles when custom mode)
     */
    public function inject_custom_colors() {
        // Get custom colors
        $colors = [
            'primary'    => get_option('gpd_color_primary', ''),
            'header'     => get_option('gpd_color_header', ''),
            'online'     => get_option('gpd_color_online', ''),
            'update'     => get_option('gpd_color_update', ''),
            'bg'         => get_option('gpd_color_bg', ''),
            'text'       => get_option('gpd_color_text', ''),
            'buy'        => get_option('gpd_color_buy', ''),
            'sell_value' => get_option('gpd_color_sell_value', ''),
            'down'       => get_option('gpd_color_down', ''),
            'border'     => get_option('gpd_color_border', '')
        ];
        
        // Filter out empty values
        $colors = array_filter($colors);
        
        // Skip if no custom colors set
        if (empty($colors)) {
            return;
        }
        
        // Map to CSS variable names
        $css_vars = [];
        if (!empty($colors['primary'])) {
            $css_vars[] = '--gpd-gold: ' . $colors['primary'];
            $css_vars[] = '--gpd-gold-dark: ' . $this->adjust_color($colors['primary'], -20);
            $css_vars[] = '--gpd-gold-dim: ' . $this->adjust_color($colors['primary'], -40);
        }
        if (!empty($colors['header'])) {
            $css_vars[] = '--gpd-header: ' . $colors['header'];
        }
        if (!empty($colors['online'])) {
            $css_vars[] = '--gpd-online: ' . $colors['online'];
        }
        if (!empty($colors['update'])) {
            $css_vars[] = '--gpd-update: ' . $colors['update'];
        }
        if (!empty($colors['bg'])) {
            $css_vars[] = '--gpd-bg-base: ' . $colors['bg'];
            $css_vars[] = '--gpd-bg-gradient: ' . $colors['bg'];
            $css_vars[] = '--gpd-bg-card: ' . $this->hex_to_rgba($colors['bg'], 0.8);
            $css_vars[] = '--gpd-bg-card-hover: ' . $this->hex_to_rgba($colors['bg'], 0.9);
        }
        if (!empty($colors['text'])) {
            $css_vars[] = '--gpd-text: ' . $colors['text'];
            $css_vars[] = '--gpd-text-secondary: ' . $this->adjust_color($colors['text'], 20);
            $css_vars[] = '--gpd-text-muted: ' . $this->adjust_color($colors['text'], 40);
        }
        if (!empty($colors['buy'])) {
            $css_vars[] = '--gpd-green: ' . $colors['buy'];
        }
        if (!empty($colors['sell_value'])) {
            $css_vars[] = '--gpd-sell-value: ' . $colors['sell_value'];
        }
        if (!empty($colors['down'])) {
            $css_vars[] = '--gpd-red: ' . $colors['down'];
        }
        if (!empty($colors['border'])) {
            $css_vars[] = '--gpd-border: ' . $colors['border'];
            $css_vars[] = '--gpd-border-light: ' . $this->hex_to_rgba($colors['border'], 0.3);
        }
        
        if (!empty($css_vars)) {
            $custom_css = ':root{' . implode(' !important;', $css_vars) . ' !important}';
            wp_add_inline_style('gold-price-display', $custom_css);
        }
    }
    
    /**
     * Convert hex to rgba
     */
    private function hex_to_rgba($hex, $alpha = 1) {
        $hex = ltrim($hex, '#');
        
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        return "rgba($r, $g, $b, $alpha)";
    }
    
    /**
     * Adjust color brightness
     */
    private function adjust_color($hex, $percent) {
        $hex = ltrim($hex, '#');
        
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        
        $r = max(0, min(255, $r + ($percent * 2.55)));
        $g = max(0, min(255, $g + ($percent * 2.55)));
        $b = max(0, min(255, $b + ($percent * 2.55)));
        
        return sprintf('#%02x%02x%02x', $r, $g, $b);
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        
        $theme_mode = get_option('gpd_theme_mode', 'dark');
        $gold_effect = get_option('gpd_gold_effect', true);
        
        // Get color settings
        $color_primary = get_option('gpd_color_primary', '');
        $color_header = get_option('gpd_color_header', '');
        $color_online = get_option('gpd_color_online', '');
        $color_update = get_option('gpd_color_update', '');
        $color_bg = get_option('gpd_color_bg', '');
        $color_text = get_option('gpd_color_text', '');
        $color_buy = get_option('gpd_color_buy', '');
        $color_sell_value = get_option('gpd_color_sell_value', '');
        $color_down = get_option('gpd_color_down', '');
        $color_border = get_option('gpd_color_border', '');
        ?>
        <div class="wrap">
            <h1>TH Gold Settings</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('gpd_settings_group'); ?>
                
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row">Theme Mode</th>
                        <td>
                            <fieldset>
                                <label>
                                    <input type="radio" name="gpd_theme_mode" value="dark" <?php checked($theme_mode, 'dark'); ?>>
                                    Dark Mode
                                </label>
                                <label style="margin-left: 15px;">
                                    <input type="radio" name="gpd_theme_mode" value="light" <?php checked($theme_mode, 'light'); ?>>
                                    Light Mode
                                </label>
                                <label style="margin-left: 15px;">
                                    <input type="radio" name="gpd_theme_mode" value="custom" <?php checked($theme_mode, 'custom'); ?>>
                                    Custom Color
                                </label>
                                <label style="margin-left: 15px;">
                                    <input type="radio" name="gpd_theme_mode" value="none" <?php checked($theme_mode, 'none'); ?>>
                                    None
                                </label>
                                <p class="description">เลือกธีมสำหรับแสดงผลราคาทอง (Default: Dark Mode)</p>
                            </fieldset>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Gold Effect</th>
                        <td>
                            <label>
                                <input type="checkbox" name="gpd_gold_effect" value="1" <?php checked($gold_effect, true); ?>>
                                เปิดใช้งาน Gold Effect
                            </label>
                            <p class="description">เอฟเฟกต์แสงวิบวับบนกล่องผลลัพธ์ราคาประเมิน (Default: เปิด)</p>
                        </td>
                    </tr>
                </table>
                
                <div id="gpd-custom-colors-section" style="<?php echo $theme_mode !== 'custom' ? 'display:none;' : ''; ?>">
                    <hr>
                    <h2>Custom Colors</h2>
                    <p class="description">ปรับแต่งสีตามต้องการ เว้นว่างไว้เพื่อใช้สีเริ่มต้นของธีม</p>
                    
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row">Primary Color (Gold)</th>
                            <td>
                                <input type="text" name="gpd_color_primary" value="<?php echo esc_attr($color_primary); ?>" class="gpd-color-picker" data-default-color="#FFD700">
                                <p class="description">สีหลัก/สีทอง - หัวข้อการ์ด (Default: #FFD700)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Header Title Color</th>
                            <td>
                                <input type="text" name="gpd_color_header" value="<?php echo esc_attr($color_header); ?>" class="gpd-color-picker" data-default-color="#FFD700">
                                <p class="description">สีหัวข้อ "ราคาทองวันนี้" (Default: #FFD700)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Online Status Color</th>
                            <td>
                                <input type="text" name="gpd_color_online" value="<?php echo esc_attr($color_online); ?>" class="gpd-color-picker" data-default-color="#4ade80">
                                <p class="description">สีข้อความ "Online" และจุดกระพริบ (Default: #4ade80 สีเขียว)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Update Time Color</th>
                            <td>
                                <input type="text" name="gpd_color_update" value="<?php echo esc_attr($color_update); ?>" class="gpd-color-picker" data-default-color="#94a3b8">
                                <p class="description">สีข้อความ "อัพเดท: XX:XX น." (Default: #94a3b8 สีเทา)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Background Color</th>
                            <td>
                                <input type="text" name="gpd_color_bg" value="<?php echo esc_attr($color_bg); ?>" class="gpd-color-picker" data-default-color="#1a1a2e">
                                <p class="description">สีพื้นหลัง (Default Dark: #1a1a2e, Light: #ffffff)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Text Color</th>
                            <td>
                                <input type="text" name="gpd_color_text" value="<?php echo esc_attr($color_text); ?>" class="gpd-color-picker" data-default-color="#ffffff">
                                <p class="description">สีข้อความ (Default Dark: #ffffff, Light: #1e293b)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Buy Price Color</th>
                            <td>
                                <input type="text" name="gpd_color_buy" value="<?php echo esc_attr($color_buy); ?>" class="gpd-color-picker" data-default-color="#4ade80">
                                <p class="description">สีราคารับซื้อ (Default: #4ade80)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Sell Value Color</th>
                            <td>
                                <input type="text" name="gpd_color_sell_value" value="<?php echo esc_attr($color_sell_value); ?>" class="gpd-color-picker" data-default-color="#FFD700">
                                <p class="description">สีราคาขายออก - ตัวเลข (Default: #FFD700 สีทอง)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Down Badge Color</th>
                            <td>
                                <input type="text" name="gpd_color_down" value="<?php echo esc_attr($color_down); ?>" class="gpd-color-picker" data-default-color="#f87171">
                                <p class="description">สี Badge เมื่อราคาลง (Default: #f87171 สีแดง)</p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">Border Color</th>
                            <td>
                                <input type="text" name="gpd_color_border" value="<?php echo esc_attr($color_border); ?>" class="gpd-color-picker" data-default-color="#D4AF37">
                                <p class="description">สีขอบ/Border (Default: rgba ของสีทอง)</p>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <?php submit_button('Save Settings'); ?>
            </form>
            
            <hr>
            
            <h2>Cache Management</h2>
            <p>ข้อมูลราคาทองไม่เปลี่ยนแปลงอาจะถูก cache ไว้ กดปุ่มด้านล่างเพื่อให้แสดงราคาอย่างถูกต้อง</p>
            <button type="button" class="button button-secondary" id="gpd-clear-cache">Clear Gold Price Cache</button>
            <span id="gpd-cache-message" style="margin-left: 10px;"></span>
            
            <script>
            jQuery(document).ready(function($) {
                $('#gpd-clear-cache').on('click', function() {
                    var $btn = $(this);
                    var $msg = $('#gpd-cache-message');
                    
                    $btn.prop('disabled', true);
                    $msg.text('Clearing...');
                    
                    $.post(ajaxurl, {
                        action: 'gpd_clear_cache',
                        _wpnonce: '<?php echo wp_create_nonce('gpd_clear_cache'); ?>'
                    }, function(response) {
                        $btn.prop('disabled', false);
                        if (response.success) {
                            $msg.css('color', 'green').text('Cache cleared successfully!');
                        } else {
                            $msg.css('color', 'red').text('Error: ' + response.data);
                        }
                        setTimeout(function() { $msg.text(''); }, 3000);
                    });
                });
                
                // Initialize color pickers
                $('.gpd-color-picker').wpColorPicker({
                    change: function(event, ui) {
                        // Color changed
                    },
                    clear: function() {
                        // Color cleared
                    }
                });
                
                // Toggle custom colors section
                $('input[name="gpd_theme_mode"]').on('change', function() {
                    if ($(this).val() === 'custom') {
                        $('#gpd-custom-colors-section').slideDown(300);
                    } else {
                        $('#gpd-custom-colors-section').slideUp(300);
                    }
                });
            });
            </script>
        </div>
        <?php
    }
    
    /**
     * AJAX clear cache
     */
    public function ajax_clear_cache() {
        check_ajax_referer('gpd_clear_cache', '_wpnonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Permission denied');
        }
        
        delete_transient('gold_price_data');
        wp_send_json_success('Cache cleared');
    }
    
    public function enqueue_styles() {
        $theme_mode = get_option('gpd_theme_mode', 'dark');
        
        if ($theme_mode !== 'none') {
            // Custom mode uses dark theme as base
            if ($theme_mode === 'custom') {
                $css_file = 'style.css';
            } else {
                $css_file = ($theme_mode === 'light') ? 'style-light.css' : 'style.css';
            }
            
            wp_enqueue_style(
                'gold-price-display',
                plugin_dir_url(__FILE__) . $css_file,
                [],
                '1.0.5'
            );
            
            // Inject custom colors after stylesheet is enqueued
            if ($theme_mode === 'custom') {
                $this->inject_custom_colors();
            }
        }
        
        add_action('wp_footer', [$this, 'realtime_clock_script']);
    }

    public function realtime_clock_script() {
        ?>
        <script>
        (function() {
            function updateClocks() {
                const clocks = document.querySelectorAll('.gpd-realtime-clock');
                if (clocks.length === 0) return;
                const now = new Date();
                const options = { timeZone: 'Asia/Bangkok', hour: '2-digit', minute: '2-digit', hour12: false };
                const timeStr = now.toLocaleTimeString('th-TH', options);
                clocks.forEach(function(clock) {
                    clock.textContent = timeStr;
                });
            }
            updateClocks();
            setInterval(updateClocks, 1000);
        })();
        </script>
        <?php
    }
    
    private function fetch_gold_price() {
        $cache_key = 'gold_price_data';
        $cached = get_transient($cache_key);
        
        if ($cached !== false) {
            return $cached;
        }
        
        $api_url = $this->api_base_url . '/api/gold/current';
        
        $response = wp_remote_get($api_url, [
            'timeout' => 15,
            'sslverify' => true,
            'headers' => [
                'Accept' => 'application/json',
                'User-Agent' => 'TH-Gold-Price-Plugin/1.0'
            ]
        ]);
        
        if (is_wp_error($response)) {
            return [
                'success' => false, 
                'error' => 'Connection Error: ' . $response->get_error_message(),
                'debug_url' => $api_url
            ];
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if ($status_code === 503 && isset($data['error']) && $data['error'] === 'API_DISABLED') {
            return [
                'success' => false,
                'error' => 'API_DISABLED',
                'message' => $data['message'] ?? 'Update! โปรดติดต่อ Developer'
            ];
        }
        
        if ($status_code !== 200) {
            return [
                'success' => false, 
                'error' => 'API Error: HTTP ' . $status_code,
                'debug_url' => $api_url
            ];
        }
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return [
                'success' => false, 
                'error' => 'JSON Parse Error: ' . json_last_error_msg(),
                'debug_url' => $api_url
            ];
        }
        
        if (!$data) {
            return [
                'success' => false, 
                'error' => 'Empty response from API',
                'debug_url' => $api_url
            ];
        }
        
        if (isset($data['success']) && $data['success']) {
            set_transient($cache_key, $data, $this->cache_time);
        }
        
        return $data;
    }
    
    private function format_number($number) {
        return number_format((float)$number, 2, '.', ',');
    }

    private function render_change_badge($change, $prefix = '') {
        if (!$change || !isset($change['amount'])) {
            return '<span class="gpd-badge gpd-unchanged">-</span>';
        }
        
        $amount = $change['amount'];
        $direction = $change['direction'] ?? 'unchanged';
        
        if ($direction === 'up') {
            $icon = '<span class="gpd-icon-up">&#9650;</span>';
            $class = 'gpd-up';
            $sign = '+';
        } elseif ($direction === 'down') {
            $icon = '<span class="gpd-icon-down">&#9660;</span>';
            $class = 'gpd-down';
            $sign = '-';
        } else {
            return '<span class="gpd-badge gpd-unchanged">-</span>';
        }
        
        return sprintf(
            '<span class="gpd-badge %s">%s%s %s%s</span>',
            esc_attr($class),
            $prefix,
            $icon,
            $sign,
            esc_html($this->format_number($amount))
        );
    }
    
    private function render_full($data) {
        $bar = $data['gold_bar'] ?? [];
        $ornament = $data['gold_ornament'] ?? [];
        $today_change = $data['today_change'] ?? [];
        $price_change = $data['price_change'] ?? [];
        $change_count = $data['change_count'] ?? 0;
        $current_time = new DateTime('now', new DateTimeZone('Asia/Bangkok'));
        
        ob_start();
        ?>
        <div class="gpd-container">
            <div class="gpd-header">
                <span class="gpd-title">ราคาทองวันนี้</span>
                <div class="gpd-header-right">
                    <span class="gpd-online"><span class="gpd-online-dot"></span>Online</span>
                    <span class="gpd-update">อัพเดท: <span class="gpd-realtime-clock"><?php echo esc_html($current_time->format('H:i')); ?></span> น.</span>
                </div>
            </div>
            
            <div class="gpd-grid">
                <div class="gpd-card">
                    <div class="gpd-card-title">ทองแท่ง 96.5%</div>
                    <div class="gpd-row">
                        <span class="gpd-label">รับซื้อ</span>
                        <span class="gpd-value gpd-buy"><?php echo esc_html($this->format_number($bar['buy'] ?? 0)); ?></span>
                    </div>
                    <div class="gpd-row">
                        <span class="gpd-label">ขายออก</span>
                        <span class="gpd-value gpd-sell"><?php echo esc_html($this->format_number($bar['sell'] ?? 0)); ?></span>
                    </div>
                </div>
                
                <div class="gpd-card">
                    <div class="gpd-card-title">ทองรูปพรรณ 96.5%</div>
                    <div class="gpd-row">
                        <span class="gpd-label">รับซื้อ</span>
                        <span class="gpd-value gpd-buy"><?php echo esc_html($this->format_number($ornament['buy'] ?? 0)); ?></span>
                    </div>
                    <div class="gpd-row">
                        <span class="gpd-label">ขายออก</span>
                        <span class="gpd-value gpd-sell"><?php echo esc_html($this->format_number($ornament['sell'] ?? 0)); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="gpd-footer">
                <div class="gpd-change-row">
                    <span class="gpd-change-label">วันนี้:</span>
                    <?php echo $this->render_change_badge($today_change); ?>
                </div>
                <div class="gpd-change-row">
                    <span class="gpd-change-label">ล่าสุด:</span>
                    <?php echo $this->render_change_badge($price_change); ?>
                    <?php if ($change_count > 0): ?>
                        <span class="gpd-count">(ครั้งที่ <?php echo esc_html($change_count); ?>)</span>
                    <?php endif; ?>
                </div>
                <?php 
                $update_date = $data['update_date'] ?? '';
                $update_time = $data['update_time'] ?? '';
                if ($update_date || $update_time): 
                ?>
                <div class="gpd-change-row gpd-datetime">
                    <span class="gpd-datetime-text"><?php echo esc_html($update_date); ?> <?php echo esc_html($update_time); ?></span>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_header($data) {
        ob_start();
        $current_time = new DateTime('now', new DateTimeZone('Asia/Bangkok'));
        ?>
        <div class="gpd-header">
            <span class="gpd-title">ราคาทองวันนี้</span>
            <div class="gpd-header-right">
                <span class="gpd-online"><span class="gpd-online-dot"></span>Online</span>
                <span class="gpd-update">อัพเดท: <span class="gpd-realtime-clock"><?php echo esc_html($current_time->format('H:i')); ?></span> น.</span>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_footer($data) {
        $today_change = $data['today_change'] ?? [];
        $price_change = $data['price_change'] ?? [];
        $change_count = $data['change_count'] ?? 0;
        $update_date = $data['update_date'] ?? '';
        $update_time = $data['update_time'] ?? '';
        
        ob_start();
        ?>
        <div class="gpd-footer">
            <div class="gpd-change-row">
                <span class="gpd-change-label">วันนี้:</span>
                <?php echo $this->render_change_badge($today_change); ?>
            </div>
            <div class="gpd-change-row">
                <span class="gpd-change-label">ล่าสุด:</span>
                <?php echo $this->render_change_badge($price_change); ?>
                <?php if ($change_count > 0): ?>
                    <span class="gpd-count">(ครั้งที่ <?php echo esc_html($change_count); ?>)</span>
                <?php endif; ?>
            </div>
            <?php if ($update_date || $update_time): ?>
            <div class="gpd-change-row gpd-datetime">
                <span class="gpd-datetime-text"><?php echo esc_html($update_date); ?> <?php echo esc_html($update_time); ?></span>
            </div>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_bar($data, $show = []) {
        $bar = $data['gold_bar'] ?? [];
        $price_change = $data['price_change'] ?? [];
        $show_header = in_array('header', $show);
        $show_footer = in_array('footer', $show);
        
        ob_start();
        ?>
        <div class="gpd-container gpd-compact">
            <?php if ($show_header): echo $this->render_header($data); endif; ?>
            <div class="gpd-card">
                <div class="gpd-card-title">ทองแท่ง 96.5%</div>
                <div class="gpd-row">
                    <span class="gpd-label">รับซื้อ</span>
                    <span class="gpd-value gpd-buy"><?php echo esc_html($this->format_number($bar['buy'] ?? 0)); ?></span>
                </div>
                <div class="gpd-row">
                    <span class="gpd-label">ขายออก</span>
                    <span class="gpd-value gpd-sell"><?php echo esc_html($this->format_number($bar['sell'] ?? 0)); ?></span>
                </div>
                <div class="gpd-row">
                    <span class="gpd-label">เปลี่ยนแปลง</span>
                    <?php echo $this->render_change_badge($price_change); ?>
                </div>
            </div>
            <?php if ($show_footer): echo $this->render_footer($data); endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_ornament($data, $show = []) {
        $ornament = $data['gold_ornament'] ?? [];
        $price_change = $data['price_change'] ?? [];
        $show_header = in_array('header', $show);
        $show_footer = in_array('footer', $show);
        
        ob_start();
        ?>
        <div class="gpd-container gpd-compact">
            <?php if ($show_header): echo $this->render_header($data); endif; ?>
            <div class="gpd-card">
                <div class="gpd-card-title">ทองรูปพรรณ 96.5%</div>
                <div class="gpd-row">
                    <span class="gpd-label">รับซื้อ</span>
                    <span class="gpd-value gpd-buy"><?php echo esc_html($this->format_number($ornament['buy'] ?? 0)); ?></span>
                </div>
                <div class="gpd-row">
                    <span class="gpd-label">ขายออก</span>
                    <span class="gpd-value gpd-sell"><?php echo esc_html($this->format_number($ornament['sell'] ?? 0)); ?></span>
                </div>
                <div class="gpd-row">
                    <span class="gpd-label">เปลี่ยนแปลง</span>
                    <?php echo $this->render_change_badge($price_change); ?>
                </div>
            </div>
            <?php if ($show_footer): echo $this->render_footer($data); endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    private function render_change($data) {
        $today_change = $data['today_change'] ?? [];
        $price_change = $data['price_change'] ?? [];
        $change_count = $data['change_count'] ?? 0;
        
        ob_start();
        ?>
        <div class="gpd-container gpd-inline">
            <span class="gpd-inline-label">ทองวันนี้:</span>
            <?php echo $this->render_change_badge($today_change); ?>
            <span class="gpd-separator">|</span>
            <span class="gpd-inline-label">ล่าสุด:</span>
            <?php echo $this->render_change_badge($price_change); ?>
            <?php if ($change_count > 0): ?>
                <span class="gpd-count">(ครั้งที่ <?php echo esc_html($change_count); ?>)</span>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }
    private function render_error($message, $debug_url = '') {
        $debug_info = '';
        if (defined('WP_DEBUG') && WP_DEBUG && $debug_url) {
            $debug_info = sprintf('<br><small style="color:#999;">URL: %s</small>', esc_html($debug_url));
        }
        return sprintf(
            '<div class="gpd-container gpd-error"><span class="gpd-error-text">%s%s</span></div>',
            esc_html($message),
            $debug_info
        );
    }
    
    private function render_api_disabled() {
        return '<div class="gpd-container gpd-error" style="text-align:center;padding:20px;">
            <span class="gpd-error-text" style="font-size:16px;font-weight:600;">Update! โปรดติดต่อ Developer</span>
        </div>';
    }
    
    public function shortcode_gold_price($atts) {
        $atts = shortcode_atts([
            'type' => 'full',
            'hide' => '',
            'show' => ''
        ], $atts, 'gold_price');
        
        $data = $this->fetch_gold_price();
        
        if (!$data || !isset($data['success']) || !$data['success']) {
            $error_code = $data['error'] ?? '';
            if ($error_code === 'API_DISABLED') {
                return $this->render_api_disabled();
            }
            $error = $data['message'] ?? $data['error'] ?? 'ไม่สามารถดึงข้อมูลราคาทองได้';
            $debug_url = $data['debug_url'] ?? '';
            return $this->render_error($error, $debug_url);
        }
        
        $hide_classes = array_filter(array_map('trim', explode(',', $atts['hide'])));
        $show_parts = array_filter(array_map('trim', explode(',', $atts['show'])));
        
        switch ($atts['type']) {
            case 'bar':
                $html = $this->render_bar($data, $show_parts);
                break;
            case 'ornament':
                $html = $this->render_ornament($data, $show_parts);
                break;
            case 'change':
                $html = $this->render_change($data);
                break;
            case 'full':
            default:
                $html = $this->render_full($data);
                break;
        }
        
        if (!empty($hide_classes)) {
            $hide_css = '<style>';
            foreach ($hide_classes as $class) {
                $hide_css .= '.' . esc_attr($class) . ' { display: none !important; }';
            }
            $hide_css .= '</style>';
            $html = $hide_css . $html;
        }
        
        return $html;
    }
    
    public function shortcode_calculator($atts) {
        $atts = shortcode_atts([], $atts, 'calculator');
        
        $data = $this->fetch_gold_price();

        if ($data && isset($data['error']) && $data['error'] === 'API_DISABLED') {
            return $this->render_api_disabled();
        }

        $bar_buy = 0;
        $ornament_buy = 0;

        if ($data && isset($data['success']) && $data['success']) {
            $bar_buy = $data['gold_bar']['buy'] ?? 0;
            $ornament_buy = $data['gold_ornament']['buy'] ?? 0;
        }
        
        return $this->render_calculator($bar_buy, $ornament_buy);
    }

    private function render_calculator($bar_buy, $ornament_buy) {
        $percent_9k = 37.5;
        $percent_14k = 58.5;
        $percent_18k = 75.0;

        $calc_id = 'gpd-calc-' . uniqid();
        
        ob_start();
        ?>
        <div class="gpd-calculator" id="<?php echo esc_attr($calc_id); ?>">
            <div class="gpd-calc-row">
                <div class="gpd-calc-field">
                    <label class="gpd-calc-label">ราคาทอง</label>
                    <div class="gpd-calc-input-wrap">
                        <input type="number" class="gpd-calc-input gpd-gold-price" value="<?php echo esc_attr($bar_buy); ?>" step="0.01">
                        <span class="gpd-calc-unit">บาท</span>
                    </div>
                </div>
                <div class="gpd-calc-field">
                    <label class="gpd-calc-label">เลือกประเภททอง</label>
                    <div class="gpd-calc-select-wrap">
                        <select class="gpd-calc-select gpd-gold-type">
                            <option value="smelted" data-show-percent="1" data-show-addon="1" data-unit="กรัม">ทองหลอม</option>
                            <option value="bar" data-show-percent="0" data-show-addon="0" data-unit="กรัม">ทองคำแท่ง 96.5%</option>
                            <option value="ornament" data-show-percent="0" data-show-addon="0" data-unit="กรัม">ทองรูปพรรณ</option>
                            <option value="frame" data-show-percent="1" data-show-addon="0" data-unit="กรัม">กรอบทอง/ตลับทอง</option>
                            <option value="9k" data-show-percent="0" data-show-addon="0" data-unit="กรัม" data-percent="<?php echo esc_attr($percent_9k); ?>">ทอง 9K</option>
                            <option value="14k" data-show-percent="0" data-show-addon="0" data-unit="กรัม" data-percent="<?php echo esc_attr($percent_14k); ?>">ทอง 14K</option>
                            <option value="18k" data-show-percent="0" data-show-addon="0" data-unit="กรัม" data-percent="<?php echo esc_attr($percent_18k); ?>">ทอง 18K</option>
                            <option value="other" data-show-percent="1" data-show-addon="0" data-unit="กรัม">อื่น ๆ</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="gpd-calc-row gpd-percent-row">
                <div class="gpd-calc-field">
                    <label class="gpd-calc-label">เปอร์เซ็นต์ทอง (%)</label>
                    <div class="gpd-calc-input-wrap">
                        <input type="number" class="gpd-calc-input gpd-percent" value="90" min="0" max="100" step="0.1">
                        <span class="gpd-calc-unit">%</span>
                    </div>
                </div>
                <div class="gpd-calc-field gpd-addon-field">
                    <label class="gpd-calc-label">ราคาบวก</label>
                    <div class="gpd-calc-input-wrap gpd-addon-wrap">
                        <input type="number" class="gpd-calc-input gpd-addon-price" value="0" step="0.01">
                        <select class="gpd-calc-select gpd-addon-unit">
                            <option value="baht">บาท</option>
                            <option value="percent">%</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="gpd-calc-row">
                <div class="gpd-calc-field gpd-full-width">
                    <label class="gpd-calc-label">น้ำหนักทอง</label>
                    <div class="gpd-calc-input-wrap">
                        <input type="number" class="gpd-calc-input gpd-weight" value="1" min="0" step="0.01">
                        <span class="gpd-calc-unit gpd-weight-unit">กรัม</span>
                    </div>
                </div>
            </div>

            <div class="gpd-calc-result">
                <div class="gpd-calc-result-label">ราคาประเมิน</div>
                <div class="gpd-calc-result-value">0.00 บาท</div>
            </div>
        </div>
        
        <script>
        (function() {
            const container = document.getElementById('<?php echo esc_js($calc_id); ?>');
            if (!container) return;
            
            const goldPriceInput = container.querySelector('.gpd-gold-price');
            const goldTypeSelect = container.querySelector('.gpd-gold-type');
            const percentInput = container.querySelector('.gpd-percent');
            const addonPriceInput = container.querySelector('.gpd-addon-price');
            const addonUnitSelect = container.querySelector('.gpd-addon-unit');
            const weightInput = container.querySelector('.gpd-weight');
            const weightUnitSpan = container.querySelector('.gpd-weight-unit');
            const percentRow = container.querySelector('.gpd-percent-row');
            const addonField = container.querySelector('.gpd-addon-field');
            const resultValue = container.querySelector('.gpd-calc-result-value');
            
            function formatNumber(num) {
                return num.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            }
            
            function updateFormFields() {
                const selected = goldTypeSelect.options[goldTypeSelect.selectedIndex];
                const showPercent = selected.dataset.showPercent === '1';
                const showAddon = selected.dataset.showAddon === '1';
                const unit = selected.dataset.unit || 'กรัม';

                if (showPercent) {
                    percentRow.style.display = '';
                } else {
                    percentRow.style.display = 'none';
                }

                if (showAddon) {
                    addonField.style.display = '';
                } else {
                    addonField.style.display = 'none';
                    // Reset addonPrice when switching to a type that doesn't use it
                    addonPriceInput.value = '0';
                }

                weightUnitSpan.textContent = unit;
                
                calculate();
            }
            
            function calculate() {
                const selected = goldTypeSelect.options[goldTypeSelect.selectedIndex];
                const goldType = goldTypeSelect.value;
                const goldPrice = parseFloat(goldPriceInput.value) || 0;
                const percent = parseFloat(percentInput.value) || 0;
                const addonPrice = parseFloat(addonPriceInput.value) || 0;
                const addonUnit = addonUnitSelect.value;
                const weight = parseFloat(weightInput.value) || 0;

                const GOLD_K_PERCENTAGES = {
                    '9k': 37.5,
                    '14k': 58.5,
                    '18k': 75.0
                };

                const optionPercent = GOLD_K_PERCENTAGES[goldType] || parseFloat(selected.dataset.percent) || 0;
                const ornamentPrice = parseFloat(goldTypeSelect.dataset.ornamentPrice) || 0;
                const GOLD_MULTIPLIER = 0.0656;
                
                let result = 0;

                if (goldType === '9k' || goldType === '14k' || goldType === '18k') {
                    result = goldPrice * GOLD_MULTIPLIER * (optionPercent / 100) * weight;
                } else if (goldType === 'bar') {
                    result = goldPrice * 0.0657894 * weight;
                } else if (goldType === 'ornament') {
                    result = goldPrice * GOLD_MULTIPLIER * 0.965 * weight;
                } else if (goldType === 'smelted') {
                    let adjustedGoldPrice = goldPrice;

                    if (addonUnit === 'baht') {
                        adjustedGoldPrice = goldPrice + addonPrice;
                    } else {
                        adjustedGoldPrice = goldPrice * (1 + (addonPrice / 100));
                    }

                    result = adjustedGoldPrice * GOLD_MULTIPLIER * (percent / 100) * weight;
                } else {
                    result = goldPrice * GOLD_MULTIPLIER * (percent / 100) * weight;
                }
                
                resultValue.textContent = formatNumber(result) + ' บาท';
                
                // Dispatch CustomEvent for other plugins (e.g., gold-checkout-qt)
                document.dispatchEvent(new CustomEvent('gpd:calculated', {
                    detail: {
                        goldType: goldType,
                        goldTypeLabel: selected.textContent,
                        goldPrice: goldPrice,
                        percent: percent,
                        addonPrice: addonPrice,
                        addonUnit: addonUnit,
                        weight: weight,
                        weightUnit: weightUnitSpan.textContent,
                        result: result,
                        resultFormatted: formatNumber(result) + ' บาท',
                        containerId: container.id,
                        timestamp: Date.now()
                    },
                    bubbles: true
                }));
            }
            
            goldTypeSelect.addEventListener('change', updateFormFields);
            goldPriceInput.addEventListener('input', calculate);
            percentInput.addEventListener('input', calculate);
            addonPriceInput.addEventListener('input', calculate);
            addonUnitSelect.addEventListener('change', calculate);
            weightInput.addEventListener('input', calculate);

            updateFormFields();
        })();
        </script>
        <?php
        return ob_get_clean();
    }
}

Gold_Price_Display::get_instance();
