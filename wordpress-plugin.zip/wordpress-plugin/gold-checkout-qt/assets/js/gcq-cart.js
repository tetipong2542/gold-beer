(function() {
    'use strict';

    const $ = s => document.querySelector(s);
    const formatNumber = n => n.toLocaleString('th-TH', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

    GCQ.cart = {
        items: [],
        total: 0,

        init: function() {
            this.container = $('#gcq-floating-cart');
            if (!this.container) return;

            this.toggle = $('.gcq-cart-toggle');
            this.badge = $('.gcq-cart-badge');
            this.panel = $('.gcq-cart-panel');
            this.itemsEl = $('.gcq-cart-items');
            this.totalEl = $('.gcq-cart-total-value');
            this.closeBtn = $('.gcq-cart-close');
            this.checkoutBtn = $('.gcq-checkout-btn');
            this.clearBtn = $('.gcq-clear-cart-btn');
            this.headerTitle = $('.gcq-cart-header h3');

            this.bindEvents();
            this.loadCart();
            this.container.classList.remove('gcq-hidden');
        },

        bindEvents: function() {
            if (this.toggle) this.toggle.addEventListener('click', () => this.togglePanel());
            if (this.closeBtn) this.closeBtn.addEventListener('click', () => this.closePanel());
            if (this.checkoutBtn) this.checkoutBtn.addEventListener('click', () => this.checkout());
            if (this.clearBtn) this.clearBtn.addEventListener('click', () => this.clearCart());

            document.addEventListener('gcq:price-updated', (e) => this.onPriceUpdated(e.detail));
            document.addEventListener('gcq:cart-updated', (e) => this.updateFromResponse(e.detail));
            
            this.bindShortcodeButtons();
        },
        
        bindShortcodeButtons: function() {
            document.querySelectorAll('.gcq-shortcode-btn').forEach(btn => {
                if (btn.dataset.gcqBound) return;
                btn.dataset.gcqBound = '1';
                btn.addEventListener('click', () => {
                    const originalText = btn.textContent;
                    btn.disabled = true;
                    btn.textContent = 'กำลังเพิ่ม...';
                    
                    GCQ.bridge.addToCart().then(res => {
                        if (res.success) {
                            btn.textContent = '✓ เพิ่มแล้ว';
                        } else {
                            btn.textContent = 'เกิดข้อผิดพลาด';
                        }
                        btn.disabled = false;
                        setTimeout(() => { btn.textContent = originalText; }, 1500);
                    }).catch(err => {
                        btn.textContent = 'กรุณากรอกข้อมูลให้ครบ';
                        btn.disabled = false;
                        setTimeout(() => { btn.textContent = originalText; }, 2000);
                    });
                });
            });
        },
        
        onPriceUpdated: function(data) {
            this.bindShortcodeButtons();
            this.showAddButton(data);
        },

        togglePanel: function() {
            this.panel.classList.toggle('gcq-hidden');
        },

        closePanel: function() {
            this.panel.classList.add('gcq-hidden');
        },

        showAddButton: function(data) {
            let addBtn = $('.gcq-add-to-cart-btn');
            if (!addBtn) {
                addBtn = document.createElement('button');
                addBtn.className = 'gcq-btn gcq-btn-primary gcq-add-to-cart-btn';
                addBtn.textContent = gcqConfig.i18n.addToCart;
                addBtn.addEventListener('click', () => {
                    GCQ.bridge.addToCart().then(() => {
                        addBtn.textContent = '✓ เพิ่มแล้ว';
                        setTimeout(() => { addBtn.textContent = gcqConfig.i18n.addToCart; }, 1500);
                    });
                });

                const calcResult = document.querySelector('.gpd-calc-result');
                if (calcResult) calcResult.appendChild(addBtn);
            }
        },

        loadCart: function() {
            fetch(gcqConfig.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'gcq_get_cart', nonce: gcqConfig.nonce })
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) this.updateFromResponse(res.data);
            });
        },

        updateFromResponse: function(data) {
            this.items = data.cart || [];
            this.total = data.total || 0;
            this.render();
        },

        render: function() {
            this.badge.textContent = this.items.length;
            this.totalEl.textContent = formatNumber(this.total) + ' บาท';
            
            if (this.headerTitle) {
                this.headerTitle.setAttribute('data-count', this.items.length);
            }

            if (this.items.length === 0) {
                this.itemsEl.innerHTML = '<div class="gcq-cart-empty">' + gcqConfig.i18n.empty + '</div>';
                return;
            }

            this.itemsEl.innerHTML = this.items.map((item, idx) => {
                const pricePerGram = item.weight > 0 ? item.result / item.weight : 0;
                const addonPrice = item.addonPrice || 0;
                const addonUnit = item.addonUnit || 'baht';
                const addonDisplay = addonPrice > 0 
                    ? (addonUnit === 'percent' ? addonPrice + '%' : formatNumber(addonPrice))
                    : '0';
                return `
                <div class="gcq-cart-item" data-id="${item.id}">
                    <div class="gcq-cart-item-header">
                        <span class="gcq-cart-item-title">${idx + 1} : ${item.goldTypeLabel}</span>
                        <button type="button" class="gcq-cart-item-remove" data-id="${item.id}" aria-label="ลบรายการ">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="15" y1="9" x2="9" y2="15"></line>
                                <line x1="9" y1="9" x2="15" y2="15"></line>
                            </svg>
                        </button>
                    </div>
                    <div class="gcq-cart-item-grid">
                        <div class="gcq-cart-item-cell">
                            <span class="gcq-cell-label">ราคา</span>
                            <span class="gcq-cell-value">${formatNumber(item.goldPrice)}</span>
                        </div>
                        <div class="gcq-cart-item-cell">
                            <span class="gcq-cell-label">ราคาบวก</span>
                            <span class="gcq-cell-value">${addonDisplay}</span>
                        </div>
                        <div class="gcq-cart-item-cell">
                            <span class="gcq-cell-label">% ซื้อ</span>
                            <span class="gcq-cell-value">${item.percent || 0}</span>
                        </div>
                        <div class="gcq-cart-item-cell">
                            <span class="gcq-cell-label">น้ำหนัก</span>
                            <span class="gcq-cell-value">${item.weight}</span>
                        </div>
                        <div class="gcq-cart-item-cell">
                            <span class="gcq-cell-label">ต่อกรัม</span>
                            <span class="gcq-cell-value">${formatNumber(pricePerGram)}</span>
                        </div>
                        <div class="gcq-cart-item-cell gcq-cell-total">
                            <span class="gcq-cell-label">ทั้งหมด</span>
                            <span class="gcq-cell-value">${formatNumber(item.result)}</span>
                        </div>
                    </div>
                </div>
            `}).join('');

            this.itemsEl.querySelectorAll('.gcq-cart-item-remove').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    const id = e.currentTarget.dataset.id;
                    this.removeItem(id);
                });
            });
        },

        removeItem: function(id) {
            fetch(gcqConfig.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'gcq_remove_from_cart', nonce: gcqConfig.nonce, itemId: id })
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) this.updateFromResponse(res.data);
            });
        },

        clearCart: function() {
            if (this.items.length === 0) return;
            if (!confirm('ต้องการลบรายการทั้งหมดใช่หรือไม่?')) return;
            
            fetch(gcqConfig.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'gcq_clear_cart', nonce: gcqConfig.nonce })
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    this.items = [];
                    this.total = 0;
                    this.render();
                }
            });
        },

        checkout: function() {
            if (this.items.length === 0) return;
            document.dispatchEvent(new CustomEvent('gcq:checkout', { bubbles: true }));
        }
    };

    document.addEventListener('DOMContentLoaded', () => GCQ.cart.init());
})();
