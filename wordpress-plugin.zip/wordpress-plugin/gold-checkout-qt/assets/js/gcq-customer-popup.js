(function() {
    'use strict';

    const $ = s => document.querySelector(s);

    GCQ.customerPopup = {
        init: function() {
            this.modal = $('#gcq-customer-popup');
            if (!this.modal) return;

            this.overlay = $('.gcq-modal-overlay');
            this.closeBtn = $('.gcq-modal-close');
            this.cancelBtn = $('.gcq-modal-cancel');
            this.submitBtn = $('.gcq-generate-qt-btn');
            this.form = $('#gcq-customer-form');

            this.bindEvents();
            this.loadSavedCustomer();
        },

        bindEvents: function() {
            document.addEventListener('gcq:checkout', () => this.open());
            this.overlay.addEventListener('click', () => this.close());
            this.closeBtn.addEventListener('click', () => this.close());
            this.cancelBtn.addEventListener('click', () => this.close());
            this.submitBtn.addEventListener('click', () => this.submit());

            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && !this.modal.classList.contains('gcq-hidden')) {
                    this.close();
                }
            });
        },

        loadSavedCustomer: function() {
            const saved = localStorage.getItem('gcq_customer');
            if (saved) {
                try {
                    const data = JSON.parse(saved);
                    $('#gcq-customer-name').value = data.name || '';
                    $('#gcq-customer-phone').value = data.phone || '';
                    $('#gcq-customer-address').value = data.address || '';
                } catch(e) {}
            }
        },

        open: function() {
            this.modal.classList.remove('gcq-hidden');
            $('#gcq-customer-name').focus();
        },

        close: function() {
            this.modal.classList.add('gcq-hidden');
        },

        submit: function() {
            const name = $('#gcq-customer-name').value.trim();
            const phone = $('#gcq-customer-phone').value.trim();
            const address = $('#gcq-customer-address').value.trim();

            if (!name) {
                $('#gcq-customer-name').focus();
                return;
            }

            localStorage.setItem('gcq_customer', JSON.stringify({ name, phone, address }));

            this.submitBtn.disabled = true;
            this.submitBtn.textContent = 'กำลังสร้าง...';

            fetch(gcqConfig.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'gcq_save_customer',
                    nonce: gcqConfig.nonce,
                    name, phone, address
                })
            })
            .then(() => fetch(gcqConfig.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({ action: 'gcq_generate_qt', nonce: gcqConfig.nonce })
            }))
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    const printWindow = window.open('', '_blank');
                    printWindow.document.write(res.data.html);
                    printWindow.document.close();
                    
                    this.close();
                    document.dispatchEvent(new CustomEvent('gcq:cart-updated', {
                        detail: { cart: [], total: 0 },
                        bubbles: true
                    }));
                } else {
                    alert(res.data?.message || 'เกิดข้อผิดพลาด');
                }
            })
            .catch(err => {
                alert('เกิดข้อผิดพลาด: ' + err.message);
            })
            .finally(() => {
                this.submitBtn.disabled = false;
                this.submitBtn.textContent = 'สร้างใบเสนอราคา';
            });
        }
    };

    document.addEventListener('DOMContentLoaded', () => GCQ.customerPopup.init());
})();
