(function() {
    'use strict';

    window.GCQ = window.GCQ || {};
    GCQ.lastCalculation = null;

    GCQ.bridge = {
        init: function() {
            document.addEventListener('gpd:calculated', this.handleCalculation.bind(this));
        },

        handleCalculation: function(e) {
            GCQ.lastCalculation = e.detail;
            document.dispatchEvent(new CustomEvent('gcq:price-updated', {
                detail: e.detail,
                bubbles: true
            }));
        },

        readFromCalculator: function(container) {
            if (!container) {
                container = document.querySelector('.gpd-calculator');
            }
            if (!container) return null;

            const goldTypeSelect = container.querySelector('.gpd-gold-type');
            const goldPriceInput = container.querySelector('.gpd-gold-price');
            const percentInput = container.querySelector('.gpd-percent');
            const addonPriceInput = container.querySelector('.gpd-addon-price');
            const addonUnitSelect = container.querySelector('.gpd-addon-unit');
            const weightInput = container.querySelector('.gpd-weight');
            const weightUnitSpan = container.querySelector('.gpd-weight-unit');
            const resultEl = container.querySelector('.gpd-calc-result-value');

            if (!goldTypeSelect || !goldPriceInput || !weightInput) return null;

            const selected = goldTypeSelect.options[goldTypeSelect.selectedIndex];
            const resultText = resultEl ? resultEl.textContent : '0';
            const resultNum = parseFloat(resultText.replace(/[^\d.-]/g, '')) || 0;

            return {
                goldType: goldTypeSelect.value,
                goldTypeLabel: selected ? selected.textContent : '',
                goldPrice: parseFloat(goldPriceInput.value) || 0,
                percent: percentInput ? parseFloat(percentInput.value) || 0 : 0,
                addonPrice: addonPriceInput ? parseFloat(addonPriceInput.value) || 0 : 0,
                addonUnit: addonUnitSelect ? addonUnitSelect.value : 'baht',
                weight: parseFloat(weightInput.value) || 0,
                weightUnit: weightUnitSpan ? weightUnitSpan.textContent : 'กรัม',
                result: resultNum,
                resultFormatted: resultText,
                timestamp: Date.now()
            };
        },

        addToCart: function(note, container) {
            let data = GCQ.lastCalculation;
            
            if (!data) {
                data = this.readFromCalculator(container);
            }
            
            if (!data || data.result <= 0) {
                return Promise.reject('No calculation or result is zero');
            }

            const item = Object.assign({}, data, { note: note || '' });

            return fetch(gcqConfig.ajaxUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    action: 'gcq_add_to_cart',
                    nonce: gcqConfig.nonce,
                    goldType: item.goldType,
                    goldTypeLabel: item.goldTypeLabel,
                    goldPrice: item.goldPrice,
                    percent: item.percent,
                    addonPrice: item.addonPrice || 0,
                    addonUnit: item.addonUnit || 'baht',
                    weight: item.weight,
                    weightUnit: item.weightUnit,
                    result: item.result,
                    note: item.note
                })
            })
            .then(r => r.json())
            .then(res => {
                if (res.success) {
                    document.dispatchEvent(new CustomEvent('gcq:cart-updated', {
                        detail: res.data,
                        bubbles: true
                    }));
                }
                return res;
            });
        }
    };

    GCQ.bridge.init();
})();
