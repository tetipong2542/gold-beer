<?php
if (!defined('ABSPATH')) exit;

class GCQ_QT_Generator {
    
    private $data;
    private const ITEMS_PER_PAGE = 15;
    
    /**
     * Get current gold prices from API cache (same as [gold_price] shortcode)
     * Returns ['bar_buy' => float, 'ornament_buy' => float] or nulls if unavailable
     */
    private function get_current_gold_prices() {
        // Try to get from transient cache (same cache used by gold-price-display plugin)
        $cached = get_transient('gold_price_data');
        
        if ($cached && isset($cached['success']) && $cached['success']) {
            return [
                'bar_buy' => floatval($cached['gold_bar']['buy'] ?? 0),
                'ornament_buy' => floatval($cached['gold_ornament']['buy'] ?? 0)
            ];
        }
        
        // Fallback: Try to fetch fresh data
        $api_url = 'https://gold-beer-production.up.railway.app/api/gold/current';
        $response = wp_remote_get($api_url, [
            'timeout' => 10,
            'sslverify' => true,
            'headers' => [
                'Accept' => 'application/json',
                'User-Agent' => 'GCQ-QT-Generator/1.0'
            ]
        ]);
        
        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
            $data = json_decode(wp_remote_retrieve_body($response), true);
            if ($data && isset($data['success']) && $data['success']) {
                return [
                    'bar_buy' => floatval($data['gold_bar']['buy'] ?? 0),
                    'ornament_buy' => floatval($data['gold_ornament']['buy'] ?? 0)
                ];
            }
        }
        
        // Ultimate fallback: return zeros
        return ['bar_buy' => 0, 'ornament_buy' => 0];
    }
    
    public function generate($data) {
        $this->data = $data;
        
        $items = $data['items'] ?? [];
        $customer = $data['customer'] ?? [];
        $shop = $data['shop'] ?? [];
        $vatRate = floatval($data['vatRate'] ?? 0);
        $termsConditions = $data['termsConditions'] ?? 'ข้าพเจ้าขอรับรองว่าทรัพย์สินที่นำมาขาย/จำนำเป็นกรรมสิทธิ์ของข้าพเจ้าโดยแท้จริง และขอรับรองว่าของที่นำมาขายนั้นเป็นของที่ได้มาโดยสุจริต หากปรากฏในภายหลังว่าเป็นของที่ได้มาโดยทุจริตหรือผิดกฎหมาย ข้าพเจ้ายินยอมรับผิดชอบทั้งทางแพ่งและอาญาทุกประการ และข้าพเจ้าได้อ่านทบทวนเอกสารฉบับนี้เรียบร้อยแล้ว จึงลงนามไว้เป็นหลักฐาน';
        
        $bangkokTz = new DateTimeZone('Asia/Bangkok');
        $now = new DateTime('now', $bangkokTz);
        
        $totalWeight = 0;
        $subtotal = 0;
        $summaryByType = [];
        
        // Calculate totals and prepare items
        foreach ($items as $i => &$item) {
            $weight = floatval($item['weight'] ?? 0);
            $result = floatval($item['result'] ?? 0);
            $type = $item['goldTypeLabel'] ?? 'อื่นๆ';
            $goldPrice = floatval($item['goldPrice'] ?? 0);
            $percent = floatval($item['percent'] ?? 0);
            
            $pricePerGram = $weight > 0 ? $result / $weight : 0;
            
            $item['index'] = $i + 1;
            $item['pricePerGram'] = $pricePerGram;
            
            $totalWeight += $weight;
            $subtotal += $result;
            
            if (!isset($summaryByType[$type])) {
                $summaryByType[$type] = ['label' => $type, 'weight' => 0, 'amount' => 0];
            }
            $summaryByType[$type]['weight'] += $weight;
            $summaryByType[$type]['amount'] += $result;
        }
        unset($item); // IMPORTANT: Break reference to prevent PHP reference bug
        
        $vat = $vatRate > 0 ? $subtotal * ($vatRate / 100) : 0;
        $netTotal = $subtotal + $vat;
        
        $docNumber = 'QT-' . $now->format('Ymd') . '-' . strtoupper(substr(uniqid(), -4));
        $issueDate = $this->formatThaiDate($now->format('Y-m-d'));
        $createdAtBkk = $now->format('d/m/Y H:i');
        
        // Get current gold prices from API (same as [gold_price] shortcode)
        $goldPrices = $this->get_current_gold_prices();
        $barPrice = $goldPrices['bar_buy'];
        $ornamentPrice = $goldPrices['ornament_buy'];
        
        // Pagination: Split items into chunks of 15
        $itemChunks = array_chunk($items, self::ITEMS_PER_PAGE);
        $totalPages = count($itemChunks);
        if ($totalPages === 0) {
            $totalPages = 1;
            $itemChunks = [[]]; // At least one empty page
        }
        
        ob_start();
        ?>
<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ใบเสนอราคา - <?php echo esc_html($shop['name'] ?? ''); ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+Thai:wght@300;400;600;700&family=Sarabun:wght@300;400;600;700&display=swap" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
  <style>
    :root {
      --primary-gold: #c59d5f;
      --dark-gold: #997b3d;
      --light-gold: #f9f3e5;
      --auspicious-red: #a93226;
      --text-dark: #333333;
      --text-grey: #666666;
      --border-color: #e0d0b8;
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Sarabun', 'Noto Sans Thai', sans-serif;
      background-color: #f0f0f0;
      padding: 20px;
      color: var(--text-dark);
      -webkit-print-color-adjust: exact;
      font-size: 11px;
    }
    .invoice-container {
      max-width: 210mm;
      min-height: 297mm;
      margin: 0 auto 20px auto;
      background-color: white;
      padding: 20px 15px;
      position: relative;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      border-top: 5px solid var(--primary-gold);
      border-bottom: 5px solid var(--primary-gold);
      display: flex;
      flex-direction: column;
      page-break-after: always;
    }
    .invoice-container:last-child {
      page-break-after: auto;
    }
    .header-section {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 12px;
      border-bottom: 2px solid var(--border-color);
      padding-bottom: 8px;
    }
    .shop-branding { display: flex; align-items: center; gap: 12px; }
    .logo-placeholder {
      width: 70px; height: 70px; border-radius: 50%;
      display: flex; align-items: center; justify-content: center; overflow: hidden;
    }
    .logo-img { width: 100%; height: 100%; object-fit: cover; }
    .logo-fallback {
      width: 100%; height: 100%;
      display: flex; align-items: center; justify-content: center;
      background-color: var(--light-gold);
      border: 1px dashed var(--border-color);
      border-radius: 50%;
      font-size: 8px; color: var(--text-grey); text-align: center;
    }
    .shop-info h1 { color: var(--dark-gold); font-size: 18px; font-weight: 700; }
    .shop-info p { font-size: 10px; color: var(--text-grey); line-height: 1.3; }
    .doc-title { text-align: right; }
    .doc-title h2 { color: var(--auspicious-red); font-size: 22px; font-weight: 700; }
    .info-grid { display: grid; grid-template-columns: 1.2fr 1fr; gap: 20px; margin-bottom: 15px; }
    .info-box h3 {
      color: var(--dark-gold); font-size: 11px;
      border-bottom: 1px solid var(--border-color);
      padding-bottom: 3px; margin-bottom: 5px; text-transform: uppercase;
    }
    .info-row { display: flex; margin-bottom: 2px; font-size: 10px; }
    .info-label { width: 90px; color: var(--text-grey); font-weight: 600; }
    .info-value { flex: 1; color: var(--text-dark); }
    .table-container { margin-bottom: 15px; flex-grow: 1; }
    table { width: 100%; border-collapse: collapse; }
    th {
      background-color: var(--light-gold); color: var(--dark-gold);
      padding: 5px 3px; font-size: 9px; font-weight: 700; text-align: center;
      border-top: 1px solid var(--primary-gold);
      border-bottom: 1px solid var(--primary-gold);
    }
    td { padding: 4px 3px; border-bottom: 1px solid #eee; font-size: 9px; vertical-align: middle; }
    .col-idx { width: 3%; text-align: center; }
    .col-desc { width: 25%; text-align: left; }
    .col-ref { width: 12%; text-align: right; }
    .col-adj { width: 10%; text-align: right; }
    .col-purity { width: 7%; text-align: center; }
    .col-weight { width: 11%; text-align: center; }
    .col-gram { width: 12%; text-align: right; }
    .col-total { width: 13%; text-align: right; font-weight: 700; font-size: 12px; }
    .item-name { font-weight: 600; }
    .item-detail { font-size: 8px; color: var(--text-grey); }
    .type-summary-box {
      margin-bottom: 12px; padding: 8px 12px;
      background-color: #fcfcfc; border: 1px solid var(--border-color); border-radius: 4px;
    }
    .type-summary-box h4 {
      font-size: 9.5px; color: var(--dark-gold); margin-bottom: 4px;
      border-bottom: 1px dashed var(--border-color); padding-bottom: 2px; text-transform: uppercase;
    }
    .type-summary-table { width: 100%; font-size: 9px; }
    .type-summary-table th { color: var(--text-grey); font-weight: 700; text-align: left; padding: 2px 4px; border-bottom: 1px solid #f0f0f0; }
    .type-summary-table td { padding: 2px 4px; border-bottom: 1px solid #f9f9f9; }
    .type-val-bold { font-weight: 600; color: var(--text-dark); font-size: 12px; }
    .summary-section { display: flex; justify-content: space-between; padding-top: 5px; }
    .payment-method {
      width: 45%; font-size: 9px; color: var(--text-dark);
      background-color: #fafafa; padding: 8px; border-radius: 4px;
      border-left: 3px solid var(--primary-gold);
    }
    .payment-method strong { display: block; margin-bottom: 6px; color: var(--dark-gold); font-size: 9.5px; }
    .payment-checkbox { display: flex; align-items: center; gap: 6px; margin-bottom: 4px; }
    .payment-checkbox input[type="checkbox"] { width: 12px; height: 12px; accent-color: var(--primary-gold); }
    .payment-input-row { display: flex; gap: 8px; margin-top: 6px; }
    .payment-input-group { flex: 1; }
    .payment-input-group label { display: block; font-size: 8px; color: var(--text-grey); margin-bottom: 2px; }
    .payment-input-group input {
      width: 100%; border: 1px solid var(--border-color); border-radius: 3px;
      padding: 8px 5px; font-size: 9px; font-family: inherit;
    }
    .totals { width: 52%; }
    .total-row { display: flex; justify-content: space-between; padding: 2px 0; font-size: 10.5px; color: var(--text-grey); }
    .total-row.grand-total {
      border-top: 2px solid var(--primary-gold);
      border-bottom: 2px solid var(--primary-gold);
      margin-top: 4px; padding: 5px 10px;
      font-size: 13px; font-weight: 700;
      color: var(--auspicious-red); background-color: var(--light-gold);
    }
    .baht-text { text-align: right; margin-top: 3px; font-style: italic; color: var(--text-grey); font-size: 9.5px; }
    .terms-disclaimer {
      margin-top: 10px; padding: 8px 12px;
      background-color: #fffdf8; border: 1px solid var(--border-color); border-radius: 4px;
      font-size: 8.5px; color: var(--text-grey); line-height: 1.5;
    }
    .terms-disclaimer strong { display: block; font-size: 9px; color: var(--dark-gold); margin-bottom: 4px; }
    .terms-disclaimer p { margin: 0; text-indent: 1.5em; }
    .footer-section { margin-top: 12px; display: flex; justify-content: space-between; }
    .signature-box { text-align: center; width: 170px; }
    .signature-line { border-bottom: 1px solid #ccc; margin-bottom: 5px; height: 25px; }
    .page-note { text-align: right; font-size: 8px; color: #999; margin-top: auto; padding-top: 10px; }
    .continued-note { text-align: center; font-size: 9px; color: var(--text-grey); padding: 10px 0; font-style: italic; }
    @media print {
      @page { size: A4; margin: 0; }
      body { background: none; padding: 0; margin: 0; }
      .invoice-container { box-shadow: none; border: none; width: 210mm; min-height: 297mm; padding: 10mm 15mm; margin: 0; }
      .no-print { display: none !important; }
    }
    .action-btns {
      position: fixed; top: 20px; right: 20px;
      display: flex; gap: 10px; z-index: 9999;
    }
    .print-btn {
      background: var(--primary-gold); color: white;
      border: none; padding: 12px 24px; border-radius: 8px;
      font-size: 14px; font-weight: 600; cursor: pointer;
      font-family: 'Sarabun', 'Noto Sans Thai', sans-serif;
    }
    .print-btn:hover { background: var(--dark-gold); }
    .save-jpg-btn {
      background: #2c7a5a; color: white;
      border: none; padding: 12px 24px; border-radius: 8px;
      font-size: 14px; font-weight: 600; cursor: pointer;
      font-family: 'Sarabun', 'Noto Sans Thai', sans-serif;
    }
    .save-jpg-btn:hover { background: #1f5e42; }
    .save-jpg-btn:disabled { background: #888; cursor: not-allowed; }
    .form-field-line {
      border-bottom: 1px solid #bbb; min-height: 22px; font-size: 9px;
      color: var(--text-grey); padding: 2px 3px; margin-top: 2px;
    }
  </style>
</head>
<body>
  <div class="action-btns no-print">
    <button class="print-btn" onclick="window.print()">พิมพ์ใบเสนอราคา</button>
    <button class="save-jpg-btn" id="saveJpgBtn" onclick="saveAsJpg()">Save Image</button>
  </div>

<?php foreach ($itemChunks as $pageIndex => $pageItems): 
    $currentPage = $pageIndex + 1;
    $isLastPage = ($currentPage === $totalPages);
    $pageNote = "หน้า {$currentPage}/{$totalPages}";
?>
  <div class="invoice-container">
    <div class="header-section">
      <div class="shop-branding">
        <div class="logo-placeholder">
          <?php if (!empty($shop['logo'])): ?>
          <img src="<?php echo esc_url($shop['logo']); ?>" alt="<?php echo esc_attr($shop['name'] ?? ''); ?>" class="logo-img"
            onload="this.style.display='block'; this.nextElementSibling.style.display='none';"
            onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';" style="display: none;">
          <?php endif; ?>
          <div class="logo-fallback" <?php echo !empty($shop['logo']) ? 'style="display:none;"' : ''; ?>>LOGO</div>
        </div>
        <div class="shop-info">
          <h1><?php echo esc_html($shop['name'] ?? 'ร้านทอง'); ?></h1>
          <p><?php echo nl2br(esc_html($shop['address'] ?? '')); ?><br>โทร: <?php echo esc_html($shop['phone'] ?? '-'); ?> | LINE: <?php echo esc_html($shop['lineId'] ?? '-'); ?></p>
        </div>
      </div>
      <div class="doc-title">
        <h2>ใบเสนอราคา</h2>
        <span style="font-size: 9px; color: var(--primary-gold); font-weight: 600; letter-spacing: 1px;">QUOTATION</span>
      </div>
    </div>

    <div class="info-grid">
      <div class="info-box">
        <h3>ลูกค้า (Customer)</h3>
        <div class="info-row">
          <div class="info-label">ชื่อลูกค้า:</div>
          <div class="info-value"><?php echo esc_html($customer['name'] ?? '-'); ?></div>
        </div>
        <div class="info-row">
          <div class="info-label">ที่อยู่:</div>
          <div class="info-value"><?php echo esc_html($customer['address'] ?? '-'); ?></div>
        </div>
        <div class="info-row">
          <div class="info-label">โทรศัพท์:</div>
          <div class="info-value"><?php echo esc_html($customer['phone'] ?? '-'); ?></div>
        </div>
      </div>
      <div class="info-box">
        <h3>ข้อมูลเอกสาร (Document)</h3>
        <div class="info-row">
          <div class="info-label">เลขที่:</div>
          <div class="info-value"><?php echo esc_html($docNumber); ?></div>
        </div>
        <div class="info-row">
          <div class="info-label">วันที่ออก:</div>
          <div class="info-value"><?php echo esc_html($issueDate); ?></div>
        </div>
        <div class="info-row">
          <div class="info-label">ราคาทองแท่ง:</div>
          <div class="info-value" style="font-weight: 700; color: var(--auspicious-red);"><?php echo number_format($barPrice, 2); ?> <span style="font-weight: 400; font-size: 9px; color: var(--text-grey);">(ณ เวลาออกเอกสาร)</span></div>
        </div>
        <div class="info-row">
          <div class="info-label">ราคารูปพรรณ:</div>
          <div class="info-value" style="font-weight: 700; color: var(--auspicious-red);"><?php echo number_format($ornamentPrice, 2); ?> <span style="font-weight: 400; font-size: 9px; color: var(--text-grey);">(ณ เวลาออกเอกสาร)</span></div>
        </div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th class="col-idx">#</th>
            <th class="col-desc">รายการสินค้า</th>
            <th class="col-ref">ราคา/1฿</th>
            <th class="col-adj">ราคาบวก</th>
            <th class="col-purity">%</th>
            <th class="col-weight">น้ำหนัก (ก.)</th>
            <th class="col-gram">ราคา/กรัม</th>
            <th class="col-total">จำนวนเงิน</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pageItems as $item): ?>
          <tr>
            <td class="col-idx"><?php echo $item['index']; ?></td>
            <td class="col-desc">
              <div class="item-name"><?php echo esc_html($item['goldTypeLabel'] ?? ''); ?></div>
              <?php if (!empty($item['note'])): ?>
              <div class="item-detail"><?php echo esc_html($item['note']); ?></div>
              <?php endif; ?>
            </td>
            <td class="col-ref"><?php echo number_format($item['goldPrice'] ?? 0, 2); ?></td>
            <td class="col-adj"><?php 
                $addonPrice = $item['addonPrice'] ?? 0;
                $addonUnit = $item['addonUnit'] ?? 'baht';
                if ($addonPrice > 0) {
                    if ($addonUnit === 'percent') {
                        echo '+' . number_format($addonPrice, 1) . '%';
                    } else {
                        echo '+' . number_format($addonPrice, 2);
                    }
                } else {
                    echo '-';
                }
            ?></td>
            <td class="col-purity"><?php echo ($item['percent'] ?? 0) > 0 ? number_format($item['percent'], 1) . '%' : '-'; ?></td>
            <td class="col-weight"><?php echo number_format($item['weight'] ?? 0, 2); ?></td>
            <td class="col-gram"><?php echo number_format($item['pricePerGram'] ?? 0, 2); ?></td>
            <td class="col-total"><?php echo number_format($item['result'] ?? 0, 2); ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

<?php if (!$isLastPage): ?>
    <!-- Continued note for non-last pages -->
    <div class="continued-note">--- ต่อหน้าถัดไป ---</div>
<?php else: ?>
    <!-- Stock Summary, Payment, Terms, Signature - ONLY on last page -->
    <div class="type-summary-box">
      <h4>สรุปยอดแยกตามประเภททอง (Stock Summary)</h4>
      <table class="type-summary-table">
        <thead>
          <tr>
            <th style="width: 35%;">รายการ (ประเภททอง)</th>
            <th style="width: 25%; text-align: center;">น้ำหนัก (กรัม)</th>
            <th style="width: 40%; text-align: right;">ราคา (บาท)</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($summaryByType as $type): ?>
          <tr>
            <td><?php echo esc_html($type['label']); ?></td>
            <td style="text-align: center;" class="type-val-bold"><?php echo number_format($type['weight'], 2); ?></td>
            <td style="text-align: right;" class="type-val-bold"><?php echo number_format($type['amount'], 2); ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="summary-section">
      <div class="payment-method">
        <strong>วิธีชำระเงิน (Payment Method)</strong>
        <div class="payment-checkbox">
          <input type="checkbox" id="pay-cash-<?php echo $currentPage; ?>">
          <label for="pay-cash-<?php echo $currentPage; ?>">เงินสด (Cash)</label>
        </div>
        <div class="payment-checkbox">
          <input type="checkbox" id="pay-transfer-<?php echo $currentPage; ?>">
          <label for="pay-transfer-<?php echo $currentPage; ?>">โอนเงิน (Transfer)</label>
        </div>
        <div class="payment-checkbox">
          <input type="checkbox" id="pay-cheque-<?php echo $currentPage; ?>">
          <label for="pay-cheque-<?php echo $currentPage; ?>">เช็ค (Cheque)</label>
        </div>
        <div class="payment-input-row">
          <div class="payment-input-group">
            <label>วันที่ชำระ (Date)</label>
            <div class="form-field-line"></div>
          </div>
          <div class="payment-input-group">
            <label>จำนวนเงิน (Amount)</label>
            <div class="form-field-line">฿</div>
          </div>
        </div>
      </div>
      <div class="totals">
        <div class="total-row"><span>น้ำหนักรวม (Total Weight)</span><span style="font-weight: 600;"><?php echo number_format($totalWeight, 2); ?> กรัม</span></div>
        <div class="total-row"><span>รวมเป็นเงิน (Subtotal)</span><span><?php echo number_format($subtotal, 2); ?> บาท</span></div>
        <?php if ($vatRate > 0): ?>
        <div class="total-row"><span>ภาษีมูลค่าเพิ่ม <?php echo $vatRate; ?>% (VAT)</span><span><?php echo number_format($vat, 2); ?> บาท</span></div>
        <?php endif; ?>
        <div class="total-row grand-total"><span>ยอดเงินสุทธิ (Net Total)</span><span><?php echo number_format($netTotal, 2); ?> บาท</span></div>
        <div class="baht-text">(<?php echo $this->numberToThaiText($netTotal); ?>)</div>
      </div>
    </div>

    <div class="terms-disclaimer">
      <strong>เงื่อนไขและข้อกำหนด (Terms & Conditions)</strong>
      <p><?php echo esc_html($termsConditions); ?></p>
    </div>

    <div class="footer-section">
      <div class="signature-box">
        <div class="signature-line"></div>
        <div style="font-size: 10px; color: var(--text-grey);">ผู้สั่งซื้อสินค้า (Customer)</div>
      </div>
      <div class="signature-box">
        <div class="signature-line"></div>
        <div style="font-size: 10px; color: var(--text-grey);">ผู้มีอำนาจลงนาม (Authorized)</div>
      </div>
    </div>
<?php endif; ?>

    <div class="page-note"><?php echo esc_html($pageNote); ?> | สร้างเมื่อ: <?php echo esc_html($createdAtBkk); ?> น.</div>
  </div>
<?php endforeach; ?>
<script>
async function saveAsJpg() {
  var btn = document.getElementById('saveJpgBtn');
  btn.disabled = true;
  btn.textContent = 'กำลังสร้าง...';

  var containers = document.querySelectorAll('.invoice-container');
  if (containers.length === 0) {
    alert('ไม่พบข้อมูลใบเสนอราคา');
    btn.disabled = false;
    btn.textContent = 'Save Image';
    return;
  }

  try {
    if (containers.length === 1) {
      // Single page: save directly
      var canvas = await html2canvas(containers[0], {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff',
        logging: false
      });
      downloadCanvas(canvas, 'quotation.jpg');
    } else {
      // Multiple pages: stitch vertically
      var gap = 10;
      var canvases = [];
      for (var i = 0; i < containers.length; i++) {
        var c = await html2canvas(containers[i], {
          scale: 2,
          useCORS: true,
          backgroundColor: '#ffffff',
          logging: false
        });
        canvases.push(c);
      }
      var totalHeight = canvases.reduce(function(sum, c) { return sum + c.height; }, 0) + gap * (canvases.length - 1);
      var maxWidth = Math.max.apply(null, canvases.map(function(c) { return c.width; }));
      var merged = document.createElement('canvas');
      merged.width = maxWidth;
      merged.height = totalHeight;
      var ctx = merged.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, maxWidth, totalHeight);
      var y = 0;
      canvases.forEach(function(c) {
        ctx.drawImage(c, 0, y);
        y += c.height + gap;
      });
      downloadCanvas(merged, 'quotation.jpg');
    }
  } catch(e) {
    alert('เกิดข้อผิดพลาด: ' + e.message);
  }

  btn.disabled = false;
  btn.textContent = 'Save Image';
}

function downloadCanvas(canvas, filename) {
  var link = document.createElement('a');
  link.download = filename;
  link.href = canvas.toDataURL('image/jpeg', 0.95);
  link.click();
}
</script>
</body>
</html>
        <?php
        return ob_get_clean();
    }
    
    private function formatThaiDate($date) {
        $months = ['', 'มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน',
                   'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
        $d = explode('-', $date);
        $year = intval($d[0]) + 543;
        $month = $months[intval($d[1])];
        $day = intval($d[2]);
        return "$day $month $year";
    }
    
    private function numberToThaiText($number) {
        $number = round($number, 2);
        $integer = floor($number);
        $decimal = round(($number - $integer) * 100);
        
        $result = $this->convertIntegerToThai($integer) . 'บาท';
        if ($decimal > 0) {
            $result .= $this->convertIntegerToThai($decimal) . 'สตางค์';
        } else {
            $result .= 'ถ้วน';
        }
        return $result;
    }
    
    private function convertIntegerToThai($number) {
        $digits = ['', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
        $units = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];
        
        if ($number == 0) return 'ศูนย์';
        
        $result = '';
        $numStr = strval($number);
        $len = strlen($numStr);
        
        for ($i = 0; $i < $len; $i++) {
            $digit = intval($numStr[$i]);
            $position = $len - $i - 1;
            $unitPos = $position % 6;
            
            if ($digit == 0) continue;
            
            if ($unitPos == 1 && $digit == 2) {
                $result .= 'ยี่';
            } elseif ($unitPos == 1 && $digit == 1) {
                // Thai: สิบ without หนึ่ง prefix
            } elseif ($unitPos == 0 && $digit == 1 && $len > 1) {
                $result .= 'เอ็ด';
            } else {
                $result .= $digits[$digit];
            }
            
            $result .= $units[$unitPos];
            
            if ($position == 6) {
                $result .= 'ล้าน';
            }
        }
        
        return $result;
    }
}
