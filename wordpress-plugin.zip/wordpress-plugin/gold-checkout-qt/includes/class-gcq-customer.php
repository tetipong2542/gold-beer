<?php
if (!defined('ABSPATH')) exit;

class GCQ_Customer {
    
    private static function get_session_key() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        return 'gcq_customer_' . substr(md5($ip . $ua), 0, 16);
    }
    
    public static function save($data) {
        set_transient(self::get_session_key(), [
            'name' => sanitize_text_field($data['name'] ?? ''),
            'phone' => sanitize_text_field($data['phone'] ?? ''),
            'address' => sanitize_textarea_field($data['address'] ?? '')
        ], DAY_IN_SECONDS);
    }
    
    public static function get() {
        return get_transient(self::get_session_key()) ?: [
            'name' => '',
            'phone' => '',
            'address' => ''
        ];
    }
    
    public static function clear() {
        delete_transient(self::get_session_key());
    }
}
