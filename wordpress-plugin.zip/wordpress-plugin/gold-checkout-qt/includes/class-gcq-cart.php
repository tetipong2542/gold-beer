<?php
if (!defined('ABSPATH')) exit;

class GCQ_Cart {
    
    private static $instance = null;
    private $session_key;
    
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        $this->session_key = 'gcq_cart_' . $this->get_user_hash();
    }
    
    private function get_user_hash() {
        $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        return substr(md5($ip . $ua), 0, 16);
    }
    
    public function add_item($item) {
        $cart = $this->get_cart();
        $cart[] = $item;
        set_transient($this->session_key, $cart, 2 * HOUR_IN_SECONDS);
    }
    
    public function remove_item($id) {
        $cart = $this->get_cart();
        $cart = array_filter($cart, function($item) use ($id) {
            return $item['id'] !== $id;
        });
        set_transient($this->session_key, array_values($cart), 2 * HOUR_IN_SECONDS);
    }
    
    public function get_cart() {
        return get_transient($this->session_key) ?: [];
    }
    
    public function get_total() {
        return array_reduce($this->get_cart(), function($sum, $item) {
            return $sum + floatval($item['result'] ?? 0);
        }, 0);
    }
    
    public function get_count() {
        return count($this->get_cart());
    }
    
    public function clear() {
        delete_transient($this->session_key);
    }
}
