<?php
/**
 * Plugin Name: Gold Checkout QT
 * Plugin URI: https://line.me/ti/p/pond_che
 * Description: Quotation generator for gold shops - integrates with TH Gold Price plugin
 * Version: 1.0.0
 * Author: Pond Dev.
 * Author URI: https://line.me/ti/p/pond_che
 * License: GPL v2 or later
 * Text Domain: gold-checkout-qt
 * Requires Plugins: gold-price-display
 */

if (!defined('ABSPATH')) {
    exit;
}

// Plugin constants
define('GCQ_VERSION', '1.0.0');
define('GCQ_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('GCQ_PLUGIN_URL', plugin_dir_url(__FILE__));
define('GCQ_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main Plugin Class
 */
class Gold_Checkout_QT {
    
    private static $instance = null;
    private $has_shortcode = false;
    private $cart_rendered = false;
    
    /**
     * Singleton instance
     */
    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        // Check dependencies
        add_action('admin_init', [$this, 'check_dependencies']);
        
        // Load includes
        $this->load_includes();
        
        // Register hooks
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_footer', [$this, 'render_cart_container']);
        
        // AJAX handlers
        add_action('wp_ajax_gcq_add_to_cart', [$this, 'ajax_add_to_cart']);
        add_action('wp_ajax_nopriv_gcq_add_to_cart', [$this, 'ajax_add_to_cart']);
        add_action('wp_ajax_gcq_get_cart', [$this, 'ajax_get_cart']);
        add_action('wp_ajax_nopriv_gcq_get_cart', [$this, 'ajax_get_cart']);
        add_action('wp_ajax_gcq_remove_from_cart', [$this, 'ajax_remove_from_cart']);
        add_action('wp_ajax_nopriv_gcq_remove_from_cart', [$this, 'ajax_remove_from_cart']);
        add_action('wp_ajax_gcq_clear_cart', [$this, 'ajax_clear_cart']);
        add_action('wp_ajax_nopriv_gcq_clear_cart', [$this, 'ajax_clear_cart']);
        add_action('wp_ajax_gcq_generate_qt', [$this, 'ajax_generate_qt']);
        add_action('wp_ajax_nopriv_gcq_generate_qt', [$this, 'ajax_generate_qt']);
        add_action('wp_ajax_gcq_save_customer', [$this, 'ajax_save_customer']);
        add_action('wp_ajax_nopriv_gcq_save_customer', [$this, 'ajax_save_customer']);
        
        // Admin menu
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        
        // Shortcodes
        add_shortcode('gcq_add_button', [$this, 'shortcode_add_button']);
        add_shortcode('gcq_cart', [$this, 'shortcode_cart']);
    }
    
    public function shortcode_add_button($atts) {
        $atts = shortcode_atts([
            'text' => 'เพิ่มลงตะกร้า',
            'class' => ''
        ], $atts);
        
        $this->has_shortcode = true;
        
        $extra_class = !empty($atts['class']) ? ' ' . esc_attr($atts['class']) : '';
        
        return '<button type="button" class="gcq-btn gcq-btn-primary gcq-add-to-cart-btn gcq-shortcode-btn' . $extra_class . '">' 
             . esc_html($atts['text']) . '</button>';
    }
    
    public function shortcode_cart($atts) {
        $this->has_shortcode = true;
        $this->cart_rendered = true;
        
        ob_start();
        ?>
        <div id="gcq-floating-cart" class="gcq-floating-cart">
            <button type="button" class="gcq-cart-toggle" aria-label="Toggle cart">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="m1 1 4 4 1 7h13l3-8H6"></path>
                </svg>
                <span class="gcq-cart-badge">0</span>
            </button>
            <div class="gcq-cart-panel gcq-hidden">
                <div class="gcq-cart-header">
                    <h3 data-count="0">รายการใบเสนอราคา</h3>
                    <button type="button" class="gcq-cart-close" aria-label="Close cart">−</button>
                </div>
                <div class="gcq-cart-items"></div>
                <div class="gcq-cart-footer">
                    <div class="gcq-cart-total">
                        <span>รวม:</span>
                        <strong class="gcq-cart-total-value">0.00 บาท</strong>
                    </div>
                    <div class="gcq-cart-footer-buttons">
                        <button type="button" class="gcq-clear-cart-btn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="15" y1="9" x2="9" y2="15"></line>
                                <line x1="9" y1="9" x2="15" y2="15"></line>
                            </svg>
                            ลบทั้งหมด
                        </button>
                        <button type="button" class="gcq-btn gcq-btn-primary gcq-checkout-btn">สร้าง</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Load include files
     */
    private function load_includes() {
        require_once GCQ_PLUGIN_DIR . 'includes/class-gcq-cart.php';
        require_once GCQ_PLUGIN_DIR . 'includes/class-gcq-customer.php';
        require_once GCQ_PLUGIN_DIR . 'includes/class-gcq-qt-generator.php';
    }
    
    /**
     * Check if gold-price-display plugin is active
     */
    public function check_dependencies() {
        if (!is_plugin_active('gold-price-display/gold-price-display.php')) {
            add_action('admin_notices', function() {
                echo '<div class="notice notice-error"><p>';
                echo '<strong>Gold Checkout QT</strong> requires <strong>TH Gold Price</strong> plugin to be installed and activated.';
                echo '</p></div>';
            });
        }
    }
    
    public function enqueue_scripts() {
        if (!$this->has_gcq_shortcode()) {
            return;
        }
        
        // CSS
        wp_enqueue_style(
            'gcq-style',
            GCQ_PLUGIN_URL . 'assets/css/gcq-style.css',
            [],
            GCQ_VERSION
        );
        
        // Bridge JS - listens for gpd:calculated events
        wp_enqueue_script(
            'gcq-bridge',
            GCQ_PLUGIN_URL . 'assets/js/gcq-bridge.js',
            [],
            GCQ_VERSION,
            true
        );
        
        // Cart JS
        wp_enqueue_script(
            'gcq-cart',
            GCQ_PLUGIN_URL . 'assets/js/gcq-cart.js',
            ['gcq-bridge'],
            GCQ_VERSION,
            true
        );
        
        // Customer popup JS
        wp_enqueue_script(
            'gcq-customer-popup',
            GCQ_PLUGIN_URL . 'assets/js/gcq-customer-popup.js',
            ['gcq-cart'],
            GCQ_VERSION,
            true
        );
        
        // Localize script
        wp_localize_script('gcq-bridge', 'gcqConfig', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('gcq_nonce'),
            'shopName' => get_option('gcq_shop_name', ''),
            'shopAddress' => get_option('gcq_shop_address', ''),
            'shopPhone' => get_option('gcq_shop_phone', ''),
            'shopLineId' => get_option('gcq_shop_line_id', ''),
            'shopLogo' => get_option('gcq_shop_logo', ''),
            'vatRate' => floatval(get_option('gcq_vat_rate', 0)),
            'i18n' => [
                'addToCart' => 'เพิ่มลงตะกร้า',
                'cart' => 'ตะกร้า',
                'checkout' => 'สร้างใบเสนอราคา',
                'empty' => 'ตะกร้าว่างเปล่า',
                'remove' => 'ลบ',
                'total' => 'รวม',
                'items' => 'รายการ',
            ]
        ]);
    }
    
    private function has_gcq_shortcode() {
        global $post;
        if (!$post) return false;
        return has_shortcode($post->post_content, 'gcq_add_button') 
            || has_shortcode($post->post_content, 'gcq_cart')
            || has_shortcode($post->post_content, 'calculator');
    }
    
    public function render_cart_container() {
        if ($this->cart_rendered) {
            $this->render_customer_modal();
            return;
        }
        
        if (!$this->has_gcq_shortcode()) {
            return;
        }
        ?>
        <div id="gcq-floating-cart" class="gcq-floating-cart">
            <button type="button" class="gcq-cart-toggle" aria-label="Toggle cart">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="9" cy="21" r="1"></circle>
                    <circle cx="20" cy="21" r="1"></circle>
                    <path d="m1 1 4 4 1 7h13l3-8H6"></path>
                </svg>
                <span class="gcq-cart-badge">0</span>
            </button>
            <div class="gcq-cart-panel gcq-hidden">
                <div class="gcq-cart-header">
                    <h3 data-count="0">รายการใบเสนอราคา</h3>
                    <button type="button" class="gcq-cart-close" aria-label="Close cart">−</button>
                </div>
                <div class="gcq-cart-items"></div>
                <div class="gcq-cart-footer">
                    <div class="gcq-cart-total">
                        <span>รวม:</span>
                        <strong class="gcq-cart-total-value">0.00 บาท</strong>
                    </div>
                    <div class="gcq-cart-footer-buttons">
                        <button type="button" class="gcq-clear-cart-btn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="15" y1="9" x2="9" y2="15"></line>
                                <line x1="9" y1="9" x2="15" y2="15"></line>
                            </svg>
                            ลบทั้งหมด
                        </button>
                        <button type="button" class="gcq-btn gcq-btn-primary gcq-checkout-btn">สร้าง</button>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $this->render_customer_modal();
    }
    
    private function render_customer_modal() {
        ?>
        <div id="gcq-customer-popup" class="gcq-modal gcq-hidden">
            <div class="gcq-modal-overlay"></div>
            <div class="gcq-modal-content">
                <div class="gcq-modal-header">
                    <h3>ข้อมูลลูกค้า</h3>
                    <button type="button" class="gcq-modal-close" aria-label="Close">&times;</button>
                </div>
                <form id="gcq-customer-form" class="gcq-modal-body">
                    <div class="gcq-form-group">
                        <label for="gcq-customer-name">ชื่อ-นามสกุล *</label>
                        <input type="text" id="gcq-customer-name" name="name" required>
                    </div>
                    <div class="gcq-form-group">
                        <label for="gcq-customer-phone">เบอร์โทรศัพท์</label>
                        <input type="tel" id="gcq-customer-phone" name="phone">
                    </div>
                    <div class="gcq-form-group">
                        <label for="gcq-customer-address">ที่อยู่</label>
                        <textarea id="gcq-customer-address" name="address" rows="2"></textarea>
                    </div>
                </form>
                <div class="gcq-modal-footer">
                    <button type="button" class="gcq-btn gcq-btn-secondary gcq-modal-cancel">ยกเลิก</button>
                    <button type="button" class="gcq-btn gcq-btn-primary gcq-generate-qt-btn">สร้างใบเสนอราคา</button>
                </div>
            </div>
        </div>
        <?php
    }
    
    public function add_admin_menu() {
        add_menu_page(
            'Gold Checkout & QT',
            'Gold QT',
            'manage_options',
            'gcq-settings',
            [$this, 'render_settings_page'],
            'dashicons-cart',
            101
        );
    }
    
    public function register_settings() {
        register_setting('gcq_settings_group', 'gcq_shop_name');
        register_setting('gcq_settings_group', 'gcq_shop_address');
        register_setting('gcq_settings_group', 'gcq_shop_phone');
        register_setting('gcq_settings_group', 'gcq_shop_line_id');
        register_setting('gcq_settings_group', 'gcq_shop_logo');
        register_setting('gcq_settings_group', 'gcq_vat_rate', [
            'type' => 'number',
            'default' => 0,
            'sanitize_callback' => 'floatval'
        ]);
        register_setting('gcq_settings_group', 'gcq_terms_conditions', [
            'type' => 'string',
            'default' => 'ข้าพเจ้าขอรับรองว่าทรัพย์สินที่นำมาขาย/จำนำเป็นกรรมสิทธิ์ของข้าพเจ้าโดยแท้จริง และขอรับรองว่าของที่นำมาขายนั้นเป็นของที่ได้มาโดยสุจริต หากปรากฏในภายหลังว่าเป็นของที่ได้มาโดยทุจริตหรือผิดกฎหมาย ข้าพเจ้ายินยอมรับผิดชอบทั้งทางแพ่งและอาญาทุกประการ และข้าพเจ้าได้อ่านทบทวนเอกสารฉบับนี้เรียบร้อยแล้ว จึงลงนามไว้เป็นหลักฐาน',
            'sanitize_callback' => 'sanitize_textarea_field'
        ]);
    }
    
    /**
     * Render settings page
     */
    public function render_settings_page() {
        if (!current_user_can('manage_options')) {
            return;
        }
        ?>
        <div class="wrap">
            <h1>Gold Checkout & QT Settings</h1>
            
            <form method="post" action="options.php">
                <?php settings_fields('gcq_settings_group'); ?>
                
                <h2>ข้อมูลร้านค้า (สำหรับใบเสนอราคา)</h2>
                <table class="form-table">
                    <tr>
                        <th scope="row"><label for="gcq_shop_name">ชื่อร้าน</label></th>
                        <td>
                            <input type="text" id="gcq_shop_name" name="gcq_shop_name" 
                                   value="<?php echo esc_attr(get_option('gcq_shop_name', '')); ?>" 
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcq_shop_address">ที่อยู่ร้าน</label></th>
                        <td>
                            <textarea id="gcq_shop_address" name="gcq_shop_address" 
                                      rows="3" class="large-text"><?php echo esc_textarea(get_option('gcq_shop_address', '')); ?></textarea>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcq_shop_phone">เบอร์โทรศัพท์</label></th>
                        <td>
                            <input type="text" id="gcq_shop_phone" name="gcq_shop_phone" 
                                   value="<?php echo esc_attr(get_option('gcq_shop_phone', '')); ?>" 
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcq_shop_line_id">LINE ID</label></th>
                        <td>
                            <input type="text" id="gcq_shop_line_id" name="gcq_shop_line_id" 
                                   value="<?php echo esc_attr(get_option('gcq_shop_line_id', '')); ?>" 
                                   class="regular-text">
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcq_shop_logo">Logo URL</label></th>
                        <td>
                            <input type="url" id="gcq_shop_logo" name="gcq_shop_logo" 
                                   value="<?php echo esc_attr(get_option('gcq_shop_logo', '')); ?>" 
                                   class="regular-text">
                            <p class="description">URL ของโลโก้ร้าน (แนะนำขนาด 200x200px)</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcq_vat_rate">VAT Rate (%)</label></th>
                        <td>
                            <input type="number" id="gcq_vat_rate" name="gcq_vat_rate" 
                                   value="<?php echo esc_attr(get_option('gcq_vat_rate', 0)); ?>" 
                                   class="small-text" min="0" max="100" step="0.01">
                            <p class="description">ใส่ 0 หากไม่ต้องการคำนวณ VAT</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="gcq_terms_conditions">เงื่อนไขและข้อกำหนด</label></th>
                        <td>
                            <textarea id="gcq_terms_conditions" name="gcq_terms_conditions" 
                                      rows="5" class="large-text"><?php echo esc_textarea(get_option('gcq_terms_conditions', 'ข้าพเจ้าขอรับรองว่าทรัพย์สินที่นำมาขาย/จำนำเป็นกรรมสิทธิ์ของข้าพเจ้าโดยแท้จริง และขอรับรองว่าของที่นำมาขายนั้นเป็นของที่ได้มาโดยสุจริต หากปรากฏในภายหลังว่าเป็นของที่ได้มาโดยทุจริตหรือผิดกฎหมาย ข้าพเจ้ายินยอมรับผิดชอบทั้งทางแพ่งและอาญาทุกประการ และข้าพเจ้าได้อ่านทบทวนเอกสารฉบับนี้เรียบร้อยแล้ว จึงลงนามไว้เป็นหลักฐาน')); ?></textarea>
                            <p class="description">ข้อความเงื่อนไขที่จะแสดงในใบเสนอราคา</p>
                        </td>
                    </tr>
                </table>
                
                <?php submit_button('บันทึกการตั้งค่า'); ?>
            </form>
        </div>
        <?php
    }
    
    // ========================================
    // AJAX Handlers
    // ========================================
    
    /**
     * Add item to cart
     */
    public function ajax_add_to_cart() {
        check_ajax_referer('gcq_nonce', 'nonce');
        
        $item = [
            'id' => uniqid('gcq_'),
            'goldType' => sanitize_text_field($_POST['goldType'] ?? ''),
            'goldTypeLabel' => sanitize_text_field($_POST['goldTypeLabel'] ?? ''),
            'goldPrice' => floatval($_POST['goldPrice'] ?? 0),
            'percent' => floatval($_POST['percent'] ?? 0),
            'addonPrice' => floatval($_POST['addonPrice'] ?? 0),
            'addonUnit' => sanitize_text_field($_POST['addonUnit'] ?? 'baht'),
            'weight' => floatval($_POST['weight'] ?? 0),
            'weightUnit' => sanitize_text_field($_POST['weightUnit'] ?? 'กรัม'),
            'result' => floatval($_POST['result'] ?? 0),
            'note' => sanitize_text_field($_POST['note'] ?? ''),
            'addedAt' => current_time('mysql')
        ];
        
        $cart = GCQ_Cart::get_instance();
        $cart->add_item($item);
        
        wp_send_json_success([
            'message' => 'เพิ่มลงตะกร้าแล้ว',
            'cart' => $cart->get_cart(),
            'total' => $cart->get_total()
        ]);
    }
    
    /**
     * Get cart contents
     */
    public function ajax_get_cart() {
        check_ajax_referer('gcq_nonce', 'nonce');
        
        $cart = GCQ_Cart::get_instance();
        
        wp_send_json_success([
            'cart' => $cart->get_cart(),
            'total' => $cart->get_total(),
            'count' => $cart->get_count()
        ]);
    }
    
    /**
     * Remove item from cart
     */
    public function ajax_remove_from_cart() {
        check_ajax_referer('gcq_nonce', 'nonce');
        
        $item_id = sanitize_text_field($_POST['itemId'] ?? '');
        
        $cart = GCQ_Cart::get_instance();
        $cart->remove_item($item_id);
        
        wp_send_json_success([
            'message' => 'ลบรายการแล้ว',
            'cart' => $cart->get_cart(),
            'total' => $cart->get_total()
        ]);
    }
    
    /**
     * Clear cart
     */
    public function ajax_clear_cart() {
        check_ajax_referer('gcq_nonce', 'nonce');
        
        $cart = GCQ_Cart::get_instance();
        $cart->clear();
        
        wp_send_json_success(['message' => 'ล้างตะกร้าแล้ว']);
    }
    
    /**
     * Save customer info
     */
    public function ajax_save_customer() {
        check_ajax_referer('gcq_nonce', 'nonce');
        
        $customer = [
            'name' => sanitize_text_field($_POST['name'] ?? ''),
            'phone' => sanitize_text_field($_POST['phone'] ?? ''),
            'address' => sanitize_textarea_field($_POST['address'] ?? '')
        ];
        
        GCQ_Customer::save($customer);
        
        wp_send_json_success(['message' => 'บันทึกข้อมูลลูกค้าแล้ว']);
    }
    
    /**
     * Generate quotation
     */
    public function ajax_generate_qt() {
        check_ajax_referer('gcq_nonce', 'nonce');
        
        $cart = GCQ_Cart::get_instance();
        $customer = GCQ_Customer::get();
        
        if ($cart->get_count() === 0) {
            wp_send_json_error(['message' => 'ตะกร้าว่างเปล่า']);
        }
        
        $generator = new GCQ_QT_Generator();
        $html = $generator->generate([
            'items' => $cart->get_cart(),
            'customer' => $customer,
            'shop' => [
                'name' => get_option('gcq_shop_name', ''),
                'address' => get_option('gcq_shop_address', ''),
                'phone' => get_option('gcq_shop_phone', ''),
                'lineId' => get_option('gcq_shop_line_id', ''),
                'logo' => get_option('gcq_shop_logo', '')
            ],
            'vatRate' => floatval(get_option('gcq_vat_rate', 0)),
            'termsConditions' => get_option('gcq_terms_conditions', 'ข้าพเจ้าขอรับรองว่าทรัพย์สินที่นำมาขาย/จำนำเป็นกรรมสิทธิ์ของข้าพเจ้าโดยแท้จริง และขอรับรองว่าของที่นำมาขายนั้นเป็นของที่ได้มาโดยสุจริต หากปรากฏในภายหลังว่าเป็นของที่ได้มาโดยทุจริตหรือผิดกฎหมาย ข้าพเจ้ายินยอมรับผิดชอบทั้งทางแพ่งและอาญาทุกประการ และข้าพเจ้าได้อ่านทบทวนเอกสารฉบับนี้เรียบร้อยแล้ว จึงลงนามไว้เป็นหลักฐาน')
        ]);
        
        // Clear cart after generating QT
        $cart->clear();
        
        wp_send_json_success([
            'html' => $html,
            'message' => 'สร้างใบเสนอราคาเรียบร้อย'
        ]);
    }
}

// Initialize plugin
Gold_Checkout_QT::get_instance();
